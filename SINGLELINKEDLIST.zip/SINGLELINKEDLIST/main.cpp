#include <iostream>
#include <list>
#include <conio.h>
#include "src\FCISLL.cpp"
using namespace std;

bool is_odd(int n)
{
    if (n % 2 != 0)
        return true;
    else
        return false;
}

bool is_even(int n)
{
    if (n % 2 == 0)
        return true;
    else
        return false;
}

int main()
{
    FCISLL<int> *mySLL = new FCISLL<int>();
    int item,index;
    int choice;
    do
    {
        cout<<"Welcome to FCI SingleLinkedList"<<endl;
        cout<<"---------------------------------"<<endl;
        cout<<"1-Add to Head\n";
        cout<<"2-Add to Tail\n";
        cout<<"3-Add to Index\n";
        cout<<"4-Remove Head\n";
        cout<<"5-Remove Tail\n";
        cout<<"6-Remove from Index\n";
        cout<<"7-Remove Item\n";
        cout<<"8-Remove with Predicate\n";
        cout<<"9-Search\n";
        cout<<"10-EXIT\n";
        cout<<"ENTER YOUR CHOICE : ";
        cin>>choice;
        int element;
        switch(choice)
        {
        case 1:
            {
                 cout<<"ENTER THE ELEMENT THAT YOU WANT TO ADD : ";
                 cin>>element;
                 mySLL->addToHead(element);
                 cout<<"THE LIST IS: ";
                 cout << *mySLL << endl;
                 break;
            }

         case 2:
            {
                 cout<<"ENTER THE ELEMENT THAT YOU WANT TO ADD : ";
                 cin>>element;
                 mySLL->addToTail(element);
                 cout<<"THE LIST IS: ";
                 cout << *mySLL << endl;
                 break;
            }

         case 3:
            {
                cout<<"ENTER THE ELEMENT YOU WANT TO INSERT : ";
                cin>>item;
                cout<<"ENTER THE INDEX THAT YOU WANT TO INSERT IN : ";
                cin>>index;
                mySLL->addToIndex(item,index);
                cout<<*mySLL<<endl;
                break;
            }

         case 4:
            {
                mySLL->removeHead();
                cout<<*mySLL<<endl;
                break;
            }
         case 5:
            {
                mySLL->removeTail();
                cout<<*mySLL<<endl;
                break;
            }
         case 6:
            {
                cout<<"ENTER THE INDEX THAT YOU WANT TO REMOVE FROM : ";
                cin>>index;
                mySLL->removeFromIndex(index);
                cout<<*mySLL<<endl;
                break;
            }
         case 7:
            {
                cout<<"ENTER THE ELEMENT YOU WANT TO REMOVE : ";
                cin>>item;
                mySLL->removeItem(item);
                cout<<*mySLL<<endl;
                break;
            }
         case 8:
            {
                char choice1;
                do
                {
                    cout<<"1-Remove all even number in list"<<endl;
                    cout<<"2-Remove all odd number in list"<<endl;
                    cout<<"3-exit"<<endl;
                    cin>>choice1;
                    switch(choice1)
                    {
                    case '1':
                        {
                            mySLL->removeWithPredicate(is_even);
                            cout<<*mySLL<<endl;
                            break;
                        }
                    case '2':
                        {
                            mySLL->removeWithPredicate(is_odd);
                            cout<<*mySLL<<endl;
                            break;
                        }
                    case '3':
                        {
                            cout<<"EXIT"<<endl;
                            break;
                        }
                    default:
                        {
                            cout<<"INVALID CHOICE"<<endl;
                            break;
                        }
                    }
                }while(choice1!='3');

                break;
            }
         case 9:
            {
                cout<<"ENTER THE ELEMENT YOU WANT TO SEARCH : ";
                cin>>item;
                cout<<mySLL->search(item)<<endl;
                break;
            }
         case 10:
            {
                cout<<"GOODBYE"<<endl;
                break;
            }
         default:
            {
                cout<<"YOU HAVE ENTERED INVALID NUMBER,PLEASE TRY AGAIN"<<endl;
                break;
            }
        }
    }while(choice!=10);

    return 0;
}






















