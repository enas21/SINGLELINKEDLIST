#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include "FCISLL.h"

using namespace std;

template <class T>
ostream& operator<< (ostream& out, Node<T> node)
{
    out << node.getData() << "->";
    return out;
 }
template <class T>
bool FCISLL<T>::isEmpty()
{
    return (length == 0);
}

////////////////////////////////
template <class T>
void FCISLL<T>::addToTail(T item) {
    Node<T>* ptr = new Node<T>(item, NULL);
    if (head == NULL)
        head = tail = ptr;
    else {
        tail->setNext(ptr);
        tail = ptr;
    }
    length++;
 }

template <class T>
void FCISLL<T>::addToHead(T item) {
    Node<T>* ptr = new Node<T>(item, head);
    head = ptr;
    if (tail == NULL)
        tail = ptr;
    length++;
 }

template <class T>
FCISLL<T>::~FCISLL() {}

template <class T>
void FCISLL<T>::addToIndex(T item, int index) {
    Node<T>* nPtr = new Node<T>(item, NULL);
    Node<T>* pPtr = head;
    for (int i = 0; pPtr != 0 && i < index - 1; i++)
        pPtr = pPtr->getNext();
    if (pPtr != 0 && !(index < 0))
        if (index == 0)
            addToHead(item);
        else {
            nPtr->setNext(pPtr->getNext());
            pPtr->setNext(nPtr);
        }
    if (tail == pPtr)
        tail = tail->getNext();
     length++;
 }

template <class T>
bool FCISLL<T>::search(T item)
{
    Node<T>* ptr = head;
    while (!(ptr == NULL) && item != ptr->getData())
        ptr = ptr->getNext();
    if (ptr != NULL)
        return true;//true=1
    else
        return false;//false=0
}

template<class T>
void FCISLL<T>::removeHead()
{
    if (length == 0)
    {
        cout << "ERROR:EMPTY LIST" << endl;
    }
    else if (length == 1)
    {
        delete head;
        tail = head = NULL;
        length--;
    }
    else
    {
        Node<T>* ptr = head;
        head = head->next;
        delete ptr;
        length--;
    }
}

template<class T>
void FCISLL<T>::removeTail()
{
    Node<T>* curr = head->next;
    Node<T>* prev = head;
    if (length == 0)
    {
        return;
    }
    else if (length == 1)
    {
        delete head;
        tail = head = NULL;
        length--;
    }
    else
    {
        while (curr != tail)
        {
            prev = curr;
            curr = curr->next;
        }
        delete curr;
        prev->next = NULL;
        tail = prev;
        length--;
    }

}


template<class T>
void FCISLL<T>::removeFromIndex(int index)
{
    if (index < 0 || index >= length)
        cout << "ERROR: Out of range" << endl;
    else
    {
        Node<T>* curr;
        Node<T>* prev;
        if (index == 0)
        {
            curr = head;
            head = head->next;
            delete curr;
            length--;
            if (length == 0)
                tail = NULL;
        }
        else
        {
            curr = head->next;
            prev = head;
            for (int i = 1; i < index; i++)
            {
                prev = curr;
                curr = curr->next;
            }

            prev->next = curr->next;
            if (tail == curr) //delete the last item
                tail = prev;
            delete curr;
            length--;
        }
    }
}

template <class T>
void FCISLL<T>::removeItem(T item)
{
    if (isEmpty())
    {
        cout << "Can not remove from empty list\n";
        return;
    }

    Node<T>* curr;
    Node<T>* prev;
    if (head->data == item)//delete the first element
    {
        curr = head;
        head = head->next;
        delete curr;
        length--;
        if (length == 0)
            tail = NULL;
    }
    else
    {
        cout << head->data << endl;
        curr = head->next;
        prev = head;
        while (curr != NULL)
        {

            if (curr->data == item)
            {
                break;
            }

            prev = curr;
            curr = curr->next;
        }

        if (curr == NULL)
        {
            cout << "The item is not found" << endl;
        }

        else
        {
            prev->next = curr->next;
            if (tail == curr)
            {
                tail = prev;
            }
            delete curr;
            length--;
        }
    }
}

template<class T>
void FCISLL<T>::removeWithPredicate(bool (predicate)( T data))
{
    Node<T>* ptr = head;
    int i=0;
    while (ptr != NULL)
    {
        if ((predicate)(ptr->getData()))
        {
            ptr = ptr->next;
            removeFromIndex(i);
            i--;
        }
        else
        {
            ptr = ptr->next;
        }

        i++;
    }

}


template <class T>
ostream& operator<<(ostream& stream, FCISLL<T> list)
{
    if (list.head != 0) {
        Node<T>* ptr = list.head;
        stream << *ptr;
        while (ptr != list.tail) {
            ptr = ptr->getNext();
            stream << *ptr;
        }
        stream << "NULL" << endl;
    }
    return stream;
}
